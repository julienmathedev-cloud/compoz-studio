/**
 * @file apps/studio/src/app/api/_adapters/pages/blocks/cells/form.ts
 * @layer studio/app/api/adapters
 *
 * @description
 * Studio API adapter for `FormCell` values.
 */

import { trimClearableOrUndef, trimOrKeep } from "@compoz/studio/lib/strings";

import type {
  FormCell,
  FormField,
} from "@compoz/core/domain/pages/entities/cell";
import type {
  FormCellIntentDTO,
  FormFieldIntentDTO,
} from "@compoz/validation/pages/blocks/cells/cell-intents";

function adaptFormField(dto: FormFieldIntentDTO): FormField {
  const base = {
    id: trimOrKeep(dto.id),
    name: trimOrKeep(dto.name),
    label: trimOrKeep(dto.label),
    placeholder: dto.placeholder ? trimOrKeep(dto.placeholder) : null,
    required: dto.required,
  };

  if (dto.type !== "select") {
    return {
      ...base,
      type: dto.type,
    };
  }

  return {
    ...base,
    type: "select",
    options: dto.options.map((option) => ({
      label: trimOrKeep(option.label),
      value: trimOrKeep(option.value),
    })),
  };
}

export function adaptFormCell(dto: FormCellIntentDTO): FormCell {
  return {
    id: trimOrKeep(dto.id),
    kind: "form",
    cssClassName: trimClearableOrUndef(dto.cssClassName),
    to: trimOrKeep(dto.to),
    submitButton: {
      label: trimOrKeep(dto.submitButton.label),
      variant: dto.submitButton.variant ?? "default",
      icon: dto.submitButton.icon ?? null,
      iconPosition:
        dto.submitButton.iconPosition === "after" ? "after" : "before",
    },
    successMessage: dto.successMessage ? trimOrKeep(dto.successMessage) : null,
    errorMessage: dto.errorMessage ? trimOrKeep(dto.errorMessage) : null,
    fields: dto.fields.map(adaptFormField),
  };
}
