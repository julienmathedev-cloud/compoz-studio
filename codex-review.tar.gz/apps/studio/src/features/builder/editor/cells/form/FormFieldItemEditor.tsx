"use client";

/**
 * @file apps/studio/src/features/builder/editor/cells/form/FormFieldItemEditor.tsx
 * @layer studio/features/builder/editor/cells/form
 *
 * @description
 * RHF-aware editor for one FormCell field item.
 *
 * @remarks
 * - Binds field settings directly through RHF `useController`.
 * - Edits name, label, type, placeholder, and required state.
 * - Shows name and label errors only after `showError` or the field has been touched.
 */

import { useTranslations } from "next-intl";
import type { Control } from "react-hook-form";
import { useController, useFieldArray } from "react-hook-form";

import { DeleteButton } from "@compoz/studio/components/atoms/buttons/DeleteButton";
import { Text } from "@compoz/studio/components/atoms/typography/Text";
import { FormGrid } from "@compoz/studio/components/layouts/FormGrid";
import { AddEmptyCardButton } from "@compoz/studio/components/molecules/controls/AddEmptyCardButton";
import { InputField } from "@compoz/studio/components/molecules/fields/InputField";
import { SelectField } from "@compoz/studio/components/molecules/fields/SelectField";
import { SwitchField } from "@compoz/studio/components/molecules/fields/SwitchField";
import { Card, CardContent } from "@compoz/ui/components/ui/card";
import { createFieldIds } from "@compoz/ui/lib/forms/use-id-prefix";
import { cn } from "@compoz/ui/lib/utils";
import { STACK_MD, STACK_SM } from "@compoz/ui/styles/studio/layout";
import type { SectionBlockFormValues } from "@compoz/validation/pages/blocks/block-form";

type FormFieldType = "text" | "email" | "textarea" | "select";

const FIELD_TYPES = ["text", "email", "textarea", "select"] as const;

type FormFieldBasePath = `rows.${number}.columns.${number}.cells.${number}`;
type FormFieldItemPath = `${FormFieldBasePath}.fields.${number}`;
type FormFieldOptionsPath = `${FormFieldItemPath}.options`;
type FormSelectOptionItemPath = `${FormFieldOptionsPath}.${number}`;

type FormSelectOptionFieldArrayItem = {
  optionId: string;
};

export type FormFieldItemEditorProps = Readonly<{
  control: Control<SectionBlockFormValues>;
  basePath: FormFieldBasePath;
  index: number;
  idPrefix: string;
  disabled?: boolean;
  canRemove?: boolean;
  onRemove: () => void;
  onTypeChange: (type: FormFieldType) => void;
  showError?: boolean;
}>;

export function FormFieldItemEditor({
  control,
  basePath,
  index,
  idPrefix,
  disabled = false,
  canRemove = true,
  onRemove,
  onTypeChange,
  showError = false,
}: FormFieldItemEditorProps) {
  const t = useTranslations();

  const itemPath = `${basePath}.fields.${index}` as FormFieldItemPath;

  const nameCtrl = useController({
    name: `${itemPath}.name` as `${FormFieldItemPath}.name`,
    control,
  });

  const labelCtrl = useController({
    name: `${itemPath}.label` as `${FormFieldItemPath}.label`,
    control,
  });

  const typeCtrl = useController({
    name: `${itemPath}.type` as `${FormFieldItemPath}.type`,
    control,
  });

  const placeholderCtrl = useController({
    name: `${itemPath}.placeholder` as `${FormFieldItemPath}.placeholder`,
    control,
  });

  const requiredCtrl = useController({
    name: `${itemPath}.required` as `${FormFieldItemPath}.required`,
    control,
  });

  const nameIds = createFieldIds(idPrefix, "name");
  const labelIds = createFieldIds(idPrefix, "label");
  const typeIds = createFieldIds(idPrefix, "type");
  const placeholderIds = createFieldIds(idPrefix, "placeholder");
  const requiredIds = createFieldIds(idPrefix, "required");

  const fieldType: FormFieldType =
    typeCtrl.field.value &&
    FIELD_TYPES.includes(typeCtrl.field.value as FormFieldType)
      ? (typeCtrl.field.value as FormFieldType)
      : "text";

  const shouldShowNameError = showError || nameCtrl.fieldState.isTouched;
  const shouldShowLabelError = showError || labelCtrl.fieldState.isTouched;

  const nameInvalid =
    shouldShowNameError && Boolean(nameCtrl.fieldState.error?.message);

  const nameError =
    shouldShowNameError && nameCtrl.fieldState.error?.message
      ? String(nameCtrl.fieldState.error.message)
      : undefined;

  const labelInvalid =
    shouldShowLabelError && Boolean(labelCtrl.fieldState.error?.message);

  const labelError =
    shouldShowLabelError && labelCtrl.fieldState.error?.message
      ? String(labelCtrl.fieldState.error.message)
      : undefined;

  return (
    <Card variant="default" visualMode="studio" className="relative">
      <CardContent className={cn(STACK_MD)}>
        <div className="absolute right-3 top-2">
          <DeleteButton
            size="icon"
            disabled={!canRemove || disabled}
            onConfirmDelete={onRemove}
            ariaLabel={t("common.delete")}
            title={t("common.delete")}
          />
        </div>

        <FormGrid>
          <InputField
            ids={nameIds}
            inputRef={nameCtrl.field.ref}
            label={t("studio.cellEditorTabs.formCellEditor.fieldNameLabel")}
            value={String(nameCtrl.field.value ?? "")}
            onChange={nameCtrl.field.onChange}
            onBlur={nameCtrl.field.onBlur}
            placeholder={t(
              "studio.cellEditorTabs.formCellEditor.fieldNamePlaceholder",
            )}
            disabled={disabled}
            help={t("studio.cellEditorTabs.formCellEditor.fieldNameHelp")}
            invalid={nameInvalid}
            error={nameError}
          />

          <InputField
            ids={labelIds}
            inputRef={labelCtrl.field.ref}
            label={t("studio.cellEditorTabs.formCellEditor.fieldLabelLabel")}
            value={String(labelCtrl.field.value ?? "")}
            onChange={labelCtrl.field.onChange}
            onBlur={labelCtrl.field.onBlur}
            placeholder={t(
              "studio.cellEditorTabs.formCellEditor.fieldLabelPlaceholder",
            )}
            disabled={disabled}
            help={t("studio.cellEditorTabs.formCellEditor.fieldLabelHelp")}
            invalid={labelInvalid}
            error={labelError}
          />
        </FormGrid>

        <FormGrid>
          <SelectField
            ids={typeIds}
            label={t("studio.cellEditorTabs.formCellEditor.fieldTypeLabel")}
            value={fieldType}
            onChange={(next) => {
              onTypeChange(next as FormFieldType);
            }}
            items={FIELD_TYPES.map((item) => ({
              value: item,
              label: t(
                `studio.cellEditorTabs.formCellEditor.fieldTypes.${item}`,
              ),
            }))}
            disabled={disabled}
            help={t("studio.cellEditorTabs.formCellEditor.fieldTypeHelp")}
          />

          <InputField
            ids={placeholderIds}
            inputRef={placeholderCtrl.field.ref}
            label={t(
              "studio.cellEditorTabs.formCellEditor.fieldPlaceholderLabel",
            )}
            value={String(placeholderCtrl.field.value ?? "")}
            onChange={placeholderCtrl.field.onChange}
            onBlur={placeholderCtrl.field.onBlur}
            placeholder={t(
              "studio.cellEditorTabs.formCellEditor.fieldPlaceholderPlaceholder",
            )}
            disabled={disabled}
            help={t(
              "studio.cellEditorTabs.formCellEditor.fieldPlaceholderHelp",
            )}
          />
        </FormGrid>

        <SwitchField
          ids={requiredIds}
          label={t("studio.cellEditorTabs.formCellEditor.fieldRequiredLabel")}
          checked={Boolean(requiredCtrl.field.value)}
          onCheckedChange={requiredCtrl.field.onChange}
          disabled={disabled}
          help={t("studio.cellEditorTabs.formCellEditor.fieldRequiredHelp")}
        />

        {fieldType === "select" ? (
          <FormSelectOptionsEditor
            control={control}
            optionsPath={`${itemPath}.options` as FormFieldOptionsPath}
            idPrefix={idPrefix}
            disabled={disabled}
            showError={showError}
          />
        ) : null}
      </CardContent>
    </Card>
  );
}

FormFieldItemEditor.displayName = "FormFieldItemEditor";

type FormSelectOptionsEditorProps = Readonly<{
  control: Control<SectionBlockFormValues>;
  optionsPath: FormFieldOptionsPath;
  idPrefix: string;
  disabled: boolean;
  showError: boolean;
}>;

function FormSelectOptionsEditor({
  control,
  optionsPath,
  idPrefix,
  disabled,
  showError,
}: FormSelectOptionsEditorProps) {
  const t = useTranslations();

  const {
    fields: options,
    append: appendOption,
    remove: removeOption,
  } = useFieldArray<
    SectionBlockFormValues,
    FormFieldOptionsPath,
    "optionId"
  >({
    control,
    name: optionsPath,
    keyName: "optionId",
  });

  return (
    <div className={cn(STACK_SM)}>
      <div className={cn(STACK_SM)}>
        <Text as="p" className="font-medium">
          {t("studio.cellEditorTabs.formCellEditor.fieldOptionsLabel")}
        </Text>

        <Text as="p" variant="muted" className="text-xs">
          {t("studio.cellEditorTabs.formCellEditor.fieldOptionsHelp")}
        </Text>
      </div>

      <div className={cn(STACK_SM)}>
        {(options as FormSelectOptionFieldArrayItem[]).map(
          (option, optionIndex) => (
            <FormSelectOptionItemEditor
              key={option.optionId}
              control={control}
              optionPath={`${optionsPath}.${optionIndex}` as FormSelectOptionItemPath}
              idPrefix={`${idPrefix}-option-${option.optionId}`}
              disabled={disabled}
              canRemove={options.length > 1}
              onRemove={() => removeOption(optionIndex)}
              showError={showError}
            />
          ),
        )}

        <div>
          <AddEmptyCardButton
            onClick={() => appendOption({ label: "", value: "" })}
            disabled={disabled}
            ariaLabel={t("common.add")}
            tooltip={t("common.add")}
            compact
          />
        </div>
      </div>
    </div>
  );
}

type FormSelectOptionItemEditorProps = Readonly<{
  control: Control<SectionBlockFormValues>;
  optionPath: FormSelectOptionItemPath;
  idPrefix: string;
  disabled: boolean;
  canRemove: boolean;
  onRemove: () => void;
  showError: boolean;
}>;

function FormSelectOptionItemEditor({
  control,
  optionPath,
  idPrefix,
  disabled,
  canRemove,
  onRemove,
  showError,
}: FormSelectOptionItemEditorProps) {
  const t = useTranslations();

  const labelCtrl = useController({
    name: `${optionPath}.label` as `${FormSelectOptionItemPath}.label`,
    control,
  });

  const valueCtrl = useController({
    name: `${optionPath}.value` as `${FormSelectOptionItemPath}.value`,
    control,
  });

  const labelIds = createFieldIds(idPrefix, "label");
  const valueIds = createFieldIds(idPrefix, "value");

  const shouldShowLabelError = showError || labelCtrl.fieldState.isTouched;
  const shouldShowValueError = showError || valueCtrl.fieldState.isTouched;

  const labelError =
    shouldShowLabelError && labelCtrl.fieldState.error?.message
      ? String(labelCtrl.fieldState.error.message)
      : undefined;

  const valueError =
    shouldShowValueError && valueCtrl.fieldState.error?.message
      ? String(valueCtrl.fieldState.error.message)
      : undefined;

  return (
    <Card variant="default" visualMode="studio" className="relative">
      <CardContent className={cn(STACK_SM)}>
        <div className="absolute right-3 top-2">
          <DeleteButton
            size="icon"
            disabled={!canRemove || disabled}
            onConfirmDelete={onRemove}
            ariaLabel={t("common.delete")}
            title={t("common.delete")}
          />
        </div>

        <FormGrid>
          <InputField
            ids={labelIds}
            inputRef={labelCtrl.field.ref}
            label={t(
              "studio.cellEditorTabs.formCellEditor.fieldOptionLabelLabel",
            )}
            value={String(labelCtrl.field.value ?? "")}
            onChange={labelCtrl.field.onChange}
            onBlur={labelCtrl.field.onBlur}
            placeholder={t(
              "studio.cellEditorTabs.formCellEditor.fieldOptionLabelPlaceholder",
            )}
            disabled={disabled}
            invalid={Boolean(labelError)}
            error={labelError}
          />

          <InputField
            ids={valueIds}
            inputRef={valueCtrl.field.ref}
            label={t(
              "studio.cellEditorTabs.formCellEditor.fieldOptionValueLabel",
            )}
            value={String(valueCtrl.field.value ?? "")}
            onChange={valueCtrl.field.onChange}
            onBlur={valueCtrl.field.onBlur}
            placeholder={t(
              "studio.cellEditorTabs.formCellEditor.fieldOptionValuePlaceholder",
            )}
            disabled={disabled}
            invalid={Boolean(valueError)}
            error={valueError}
          />
        </FormGrid>
      </CardContent>
    </Card>
  );
}
